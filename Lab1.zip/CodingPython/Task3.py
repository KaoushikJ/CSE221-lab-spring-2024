input_file=open('Input3.txt','r')
lenth=int(input_file.readline())
arr1=[int(i) for i in (input_file.readline().split(" "))]
arr2=[int(i) for i in (input_file.readline().split(" "))]
for i in range(lenth):
    arr2[i]=arr2[i]-arr1[i]
count=0
for i in range(lenth-1):
    min=i
    for j in range(i+1,lenth):
        if arr2[j]>arr2[min]:
            min=j
    if i!=min:
        arr2[min],arr2[i]=arr2[i],arr2[min]
        arr1[min],arr1[i]=arr1[i],arr1[min]
        count+=1
output_file=open('Output3.txt','w')
for i in range(lenth):
    if i==lenth-1:
        output_file.write(f"ID: {arr1[i]} Mark: {arr2[i]+arr1[i]}")
    else:
        output_file.write(f"ID: {arr1[i]} Mark: {arr2[i]+arr1[i]}\n")
output_file.write(f"\nNumber of swap: {count}")
input_file.close()
output_file.close()

#Firstly I made 2 arrays from the input file. where arr1 is for the id and arr2 is for the marks.
#first i substracted ids from the corresponding marks.
# in this way if the array get sorted i can add the ids back and have both the arrays sorted fullfilling all the rules. 
#After substracting I used selection sort to sort both the arrays.
#finally after using a for loop The output text is written in the output file.
# while writtimg the output file I added the substracted part back. 