inpt_file=open('Input4.txt','r')
iter=int(inpt_file.readline())

all=[" "]*iter
train=[" "]*iter
time=[0]*iter
for i in range(iter):
    all[i]=inpt_file.readline()
    temp=all[i].strip(" ").split(" ")
    train[i]=temp[0]
    time[i]=temp[len(temp)-1].split(":")
    
for i in range(iter-1):
    min=i
    for j in range(i+1,iter):
        if train[j]<train[min]:
            min=j
        elif (train[j]==train[min]):
            if (time[j][0]+time[j][1]) > (time[min][0]+time[min][1]):
                min=j
    train[min],train[i]=train[i],train[min]
    all[min],all[i]=all[i],all[min]
    time[min],time[i]=time[i],time[min]
    
inpt_file.close()   
 
out_file=open('Output4.txt', 'w')
for i in range(iter):
    out_file.write(f"{all[i]}")      
out_file.close()        


#First i created three empty arry for storing the whole data, train name and depurture time accordingly.
# Then I stored the data individually in the arrays accoedingly
#Then I used the selection sort to sort the arrays lexicographically using "train" array. (all the arrays have the datas connected by their coresponding index)
#finally using the sorted array "all", I wrote the output in the output file.
       