input_file=open('Input2.txt','r')
output_file=open('Output2.txt','w')
test_case=int(input_file.readline())
arr=[int(i) for i in input_file.readline().split(" ")]
def bubblesort(arr):
    t=0
    for i in range(len(arr)-1):
        flag=True
        for j in range(len(arr)-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
                flag=False
            t+=1
        if flag:
            break
    for i in arr:
        output_file.write(str(i)+" ")
    output_file.write(f"\nNumber of write is {t}")
    input_file.close()
    output_file.close()
bubblesort(arr)
# To ensure the least amount of swap in the bubble sort,
# I took the elements present in the input file as an integer array,
# and added two flags in the fist loop and in the "if" condition of the second loop accordingly.
#The fist flag is a "True" boolean flag. Which will reamin true if the array is already sorted (best case scenerio).
#And the second flag is a "False" boolean.
#Which will make the breaking condition flase if ay unsorted elements are found in the array.
# The bubblesort function will sort the unsorted array
#and as soon as the the array is found sorted the break function will execute causing the loop to terminate.
#Thus the array gets sorted with the bare minimum of swaps.