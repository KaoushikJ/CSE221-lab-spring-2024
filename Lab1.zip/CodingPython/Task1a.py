inpt=open('Input1a.txt','r')
outp=open('Output1a.txt','w')
test_case=int(inpt.readline())
for i in range(test_case):
    num=int(inpt.readline())
    if num%2==0:
        x="Even"
    else:
        x="Odd"
    if i!=test_case-1:
        outp.write(f"{num} is an {x} number.\n")
    else:
        outp.write(f"{num} is an {x} number.")
inpt.close()
outp.close()

#In this problem, a number is taken from the input file one at a time
#and checked if that number is an "Even" or an "Odd" number by moding them by 2.7
#After identifying the number the outcomes are added to the output file accordingly.