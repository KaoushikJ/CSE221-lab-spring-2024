input_file=open('Input1b.txt','r')
output_file=open('Output1b.txt','w')
test_case=int(input_file.readline())
for i in range(test_case):
    line_lst=input_file.readline().strip(" ").split(" ")
    num1=int(line_lst[1])
    num2=int(line_lst[3])
    op=line_lst[2]
    if op=="+":
        rslt=num1+num2
    elif op=="-":
        rslt=num1-num2
    elif op=="/":
        rslt=num1/num2
    elif op=="*":
        rslt=num1*num2
    if i!=test_case-1:
        output_file.write(f"The result of {num1} {op} {num2} is {rslt}\n")
    else:
        output_file.write(f"The result of {num1} {op} {num2} is {rslt}")
input_file.close()
output_file.close()

#In this task each line is read from the input file and done the bellow mentioned tasks accordingly
# 1. strip(" ") is used to remove the unwanted spaces infront and rare of the line.
# 2. split(" ") is used to defferentiate the items present in the input file and make a list consisting each element present in the line kn the input file.
#Finally using a for lopp and some conditions to complete the calculations and add them to the output file.