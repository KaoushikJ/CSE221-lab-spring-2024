#task 3
def creat_graph_map(inpt):
    t=inpt.readline().strip().split(" ")
    c_node=int(t[0])
    u=int(t[1])
    map={}
    t_map={}

    for i in range(1,c_node+1):
        map[i]=[]
        t_map[i]=[]
    for i in range(u):
        t=inpt.readline().strip().split(" ")
        vert=int(t[0])
        dest=int(t[1])
        map[vert].append(dest)
        t_map[dest].append(vert)
    return map,t_map
inpt=open("Input3.txt","r")
map,t_map=creat_graph_map(inpt)
inpt.close()

def part_top_dfs(map,start,visited,stack):
    if start not in visited :
        visited.append(start)
        for i in map[start]:
            x=part_top_dfs(map,i,visited,stack)
        stack.append(start)
        
def s_check(G, S_comp, visited, c_node):
    visited.append(c_node)
    S_comp.append(c_node)
    for i in G[c_node]:
        if i not in visited:
            s_check(G, S_comp, visited, i )


def Strongly_Connected_Components(G,T_G):
    visited=[]
    stack=[]
    keys=list(map.keys())
    for i in keys:
        if i not in visited:
            part_top_dfs(map,i,visited,stack)
    visited = []
    scc_components = []

    while stack:
        c_node = stack.pop()
        if c_node!= 0:
            if c_node not in visited:
                S_comp = []
                s_check(T_G, S_comp, visited,  c_node)
                scc_components.append(S_comp)

    return scc_components

scc = Strongly_Connected_Components(map,t_map)
outpt=open("Output3.txt","w")
for i in scc:
    for k in i:
        outpt.write(f"{k} ")
    if i!=scc[len(scc)-1]:
        outpt.write("\n")
outpt.close()