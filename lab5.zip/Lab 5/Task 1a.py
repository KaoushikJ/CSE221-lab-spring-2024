#task 1a Usinmap Dfs
inpt=open("Input1a.txt","r")

def creat_graph_map(inpt):
    t=inpt.readline().strip().split(" ")
    v=int(t[0])
    u=int(t[1])
    map={}
    

    for i in range(1,v+1):
        map[i]=[]
        
    for i in range(u):
        t=inpt.readline().strip().split(" ")
        vert=int(t[0])
        dest=int(t[1])
        map[vert].append(dest)
    return map

map=creat_graph_map(inpt)
inpt.close()

def top_sort_dfs(map,start,visited,stack):
    if start not in visited :
        visited.append(start)
        if len(map[start])==0:
            stack.append(start)
            return False
        for i in map[start]:
            x=top_sort_dfs(map,i,visited,stack)
        stack.append(start)
        return x
    elif start not in stack:
        return True

def call_for_top(key,visited,stack):
    for i in key:
        if i not in visited:
            x=top_sort_dfs(map,i,visited,stack)
        if x:
            return "IMPOSSIBLE"
    return stack[-1::-1]


key=list(map.keys())
visited=[]
stack=[]
sort=call_for_top(key,visited,stack)
outpt=open("Output1a.txt","w")
print(sort)
if type(sort)==str:
    outpt.write(sort) 
else:
    for final in sort:
        outpt.write(f"{final} ")
outpt.close()