#task 1b Using BFS
inpt=open("Input1b.txt","r")
def creat_graph_map(inpt):
    t=inpt.readline().strip().split(" ")
    v=int(t[0])
    u=int(t[1])
    map={}
    in_degree={}

    for i in range(1,v+1):
        map[i]=[]
        in_degree[i]=0
    for i in range(u):
        t=inpt.readline().strip().split(" ")
        vert=int(t[0])
        dest=int(t[1])
        map[vert].append(dest)
        in_degree[dest]+=1

    return map, in_degree

map, in_degree=creat_graph_map(inpt)
inpt.close()

def top_sort_bfs(G,queue,visited,sort,indeg):
    cycle_count=0
    for i in G:
        if indeg[i]==0:
            queue.append(i)

    while len(queue)!=0:
        node=queue.pop(0)
        sort.append(node)
        cycle_count+=1
        for c_node in G[node]:
            indeg[c_node]-=1
            if indeg[c_node] == 0:
                queue.append(c_node)
    if cycle_count!= len(G):
        return "IMPOSSIBLE"
    else: 
        return sort

nodes=list(map.keys())
visited=[]
queue=[]
stack=[]
sort=top_sort_bfs(map,queue,visited,stack,in_degree)
outpt=open("Output1b.txt","w")
if type(sort)==str:
    outpt.write(sort) 
else:
    for final in sort:
        outpt.write(f"{final} ")
outpt.close()
print(map)