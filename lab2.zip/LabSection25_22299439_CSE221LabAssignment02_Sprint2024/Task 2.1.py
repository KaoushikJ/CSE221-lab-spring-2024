#Task 2.1
inpt=open('Input2.1.txt','r')
iter1=int(inpt.readline())
arr1=[int(i) for i in inpt.readline().split(" ")]
iter2=int(inpt.readline())
arr2=[int(i) for i in inpt.readline().split(" ")]
new=arr1+arr2
new.sort()
outpt=open('Output2.1.txt','w')
for i in range(iter1+iter2):
    outpt.write(f"{new[i]} ")
inpt.close()
outpt.close()
