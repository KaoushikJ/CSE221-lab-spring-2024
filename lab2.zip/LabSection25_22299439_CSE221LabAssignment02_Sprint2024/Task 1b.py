#task 1b
inpt=open("Input1b.txt","r")
outpt=open("Output1b.txt","w")
t=inpt.readline().split(" ")
iter=int(t[0])
target=int(t[1])
arr=[int(i) for i in inpt.readline().split(" ")]
p1=0
p2=iter-1
t=False
while p1!=p2:
    if arr[p1]+arr[p2]==target:
        t=True
        break
    elif arr[p1]+arr[p2]<target:
        p1+=1
    elif arr[p1]+arr[p2]>target or arr[p2]>=target:
        p2=p2-1
    if arr[p1]>=target:
        break
if t:
    outpt.write(f"{p1+1} {p2+1}")
else:
    outpt.write("IMPOSSIBLE")
inpt.close()
outpt.close()