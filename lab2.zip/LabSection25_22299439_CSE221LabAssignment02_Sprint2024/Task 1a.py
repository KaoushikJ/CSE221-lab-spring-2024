#TASK 1a
inpt=open("Input1a.txt","r")

t=inpt.readline().split(" ")
iter=int(t[0])
target=int(t[1])
arr=[int(i) for i in inpt.readline().split(" ")]
x=None
y=None
for i in range(iter-1):
    t=False
    for j in range(i+1,iter):
        if arr[i]+arr[j]==target:
            t=True
            x=i
            y=j
            break
    if t:
        break
outpt=open("Output1a.txt","w")
if x==None and y==None:
    outpt.write("IMPOSSIBLE")
else:
    outpt.write(f"{i+1} {y+1}")
inpt.close()
outpt.close()