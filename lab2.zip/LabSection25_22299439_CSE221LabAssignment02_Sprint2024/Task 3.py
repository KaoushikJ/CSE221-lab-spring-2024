#Task 3
def task_count():
    inpt=open("Input3.txt","r")
    
    iter=int(inpt.readline())
    arr=[0]*iter

    for i in range(iter):
        arr[i]=[int(num) for num in inpt.readline().split(" ")]

    for i in range(iter-1):
        min=i
        for j in range(i+1,iter):
            if arr[j][1]<arr[min][1]:
                min=j
        arr[i],arr[min]=arr[min],arr[i]

    count=0
    k=[0]*iter
    t=0

    for i in range(iter):
        if i==0:
            k[t]=arr[i]
            t+=1
        elif arr[i][0]>=k[t-1][1]:
            k[t]=arr[i]
            t+=1
    outpt=open("output3.txt","w")
    outpt.write(f"{t}\n")
    for i in range(iter):
        if k[i]==0:
            break
        outpt.write(f"{k[i]}\n")
    inpt.close()
    outpt.close()
task_count()