#task 2.2
inpt=open('Input2.2.txt','r')
iter1=int(inpt.readline())
arr1=[int(i) for i in inpt.readline().split(" ")]
iter2=int(inpt.readline())
arr2=[int(i) for i in inpt.readline().split(" ")]
c1,c2=0,0
new=[0]*(iter1+iter2)

for i in range(iter1+iter2):
    if c1<iter1 and c2<iter2:
        if arr1[c1]<arr2[c2]:
            new[i]=arr1[c1]
            c1+=1
        else:
            new[i]=arr2[c2]
            c2+=1
    elif c1==iter1 and c2<iter2:
        new[i]=arr2[c2]
        c2+=1
    elif c2==iter2 and c1<iter1:
        new[i]=arr1[c1]
outpt=open('Output2.2.txt','w')
for i in range(iter1+iter2):
    outpt.write(f"{new[i]} ")
inpt.close()
outpt.close()

