#Task 4
def greedy()
    inpt=open('Input4.txt','r')
    x=inpt.readline().split( )

    iter=int(x[0])
    ppl=int(x[1])
    arr=[0]iter
    work=[0]ppl

    for i in range(iter)
        arr[i]=[int(num) for num in inpt.readline().split( )]

    for i in range(iter-1)
        min=i
        for j in range(i+1,iter)
            if arr[j][1]arr[min][1]
                min=j
        arr[i],arr[min]=arr[min],arr[i]
    count=0

    for i in range(iter)
        diff=25 #as time can only go up to 24 hours.
        k=0
        t=False
        for j in range(ppl)   
            if arr[i][0]=work[j] and arr[i][0]-work[j]diff
                diff=arr[i][0]-work[j]
                k=j
                t=True
        if t
            work[k]=arr[i][1]
            count+=1
    outpt=open('Output4.txt','w')
    outpt.write(f{count})

greedy()