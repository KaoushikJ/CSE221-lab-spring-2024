#task 3
def dfs(graph, start, visited):
    temp=graph[start]
    for next_node in temp:
        if next_node not in visited:
            visited.append(next_node)
            dfs(graph,next_node,visited)
    return visited

inpt=open("input3.txt","r")
outpt=open("output3.txt","w")
temp=[int(i) for i in inpt.readline().split(" ")]
n,m=temp[0],temp[1]
graph = {}

for i in range(m):
    temp=[int(i) for i in inpt.readline().split(" ")]
    x=temp[0] not in graph
    y=temp[1] not in graph
    if  x or y:
        if x:
            graph[temp[0]]=[temp[1]]
        else:
            graph[temp[0]].append(temp[1])
        if y:
            graph[temp[1]]=[temp[0]]
        else:
            graph[temp[1]].append(temp[0])

    else:
        graph[temp[0]].append(temp[1])
        graph[temp[1]].append(temp[0])

start=1
visited=[1]
path=dfs(graph,start,visited)
bfs_order = bfs(graph, 1)
for i in path:
    outpt.write(f'{i} ')
outpt.close()
inpt.close()