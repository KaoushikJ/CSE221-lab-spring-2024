#task 2
def bfs(graph, start_node):
    visited = []
    queue = [start_node]
    result = []
    while len(queue)!=0:
        current_node = queue.pop(0)
        if current_node not in visited:
            result.append(current_node)
            visited.append(current_node)
            for neighbor in graph[current_node]:
                if neighbor not in visited:
                    queue.append(neighbor)
    return result

inpt=open("input2.txt","r")
outpt=open("output2.txt","w")
temp=[int(i) for i in inpt.readline().split(" ")]
n,m=temp[0],temp[1]
graph = {}

for i in range(m):
    temp=[int(i) for i in inpt.readline().split(" ")]
    x=temp[0] not in graph
    y=temp[1] not in graph
    if  x or y:
        if x:
            graph[temp[0]]=[temp[1]]
        else:
            graph[temp[0]].append(temp[1])
        if y:
            graph[temp[1]]=[temp[0]]
        else:
            graph[temp[1]].append(temp[0])

    else:
        graph[temp[0]].append(temp[1])
        graph[temp[1]].append(temp[0])


bfs_order = bfs(graph, 1)
for i in bfs_order:
    outpt.write(f'{i} ')
outpt.close()
inpt.close()
