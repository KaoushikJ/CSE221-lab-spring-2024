#task 1a
import numpy as np
inpt=open("input1a.txt","r")
outpt=open("output1a.txt","w")
temp=inpt.readline().split(" ")
vert=int(temp[0])
edge=int(temp[1])
matrix=np.zeros((vert+1,vert+1),dtype=int)

for i in range(edge):
    temp=[int(i) for i in inpt.readline().split(" ")]
    matrix[temp[0]][temp[1]]=temp[2]

for i in range(vert+1):
    for j in range((vert+1)):
        outpt.write(f"{matrix[i][j]} ")
    if i!=vert:
        outpt.write("\n")
inpt.close()
outpt.close()