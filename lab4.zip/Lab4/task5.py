#task 5
inpt=open("input5.txt","r")
outpt=open("output5.txt","w")
temp=[int(i) for i in inpt.readline().split(" ")]
n,m=temp[0],temp[1]
destination=temp[2]
graph = {}

for i in range(m):
    temp=[int(i) for i in inpt.readline().split(" ")]
    x=temp[0] not in graph
    y=temp[1] not in graph
    if  x or y:
        if x:
            graph[temp[0]]=[temp[1]]
        else:
            graph[temp[0]].append(temp[1])
        if y:
            graph[temp[1]]=[temp[0]]
        else:
            graph[temp[1]].append(temp[0])

    else:
        graph[temp[0]].append(temp[1])
        graph[temp[1]].append(temp[0])
    
queue = [1]
visited = {1:0}
parent = {}
while len(queue)!=0:
    p = queue.pop(0)
    for i in graph[p]:
        if i not in visited:
            queue.append(i)
            parent[i] = p
            visited[i] = visited[parent[i]] + 1

node = destination

path = [node]
while node!=1:
    node = parent[node]
    path.insert(0, node)
    
outpt.write(f"Time: {visited[destination]}\nShortest Path:")    
for i in path:
    outpt.write(f' {i}')
outpt.close()
inpt.close()