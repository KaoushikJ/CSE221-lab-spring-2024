#Task 4
def dfs(graph, start, visited):
    temp=graph[start]
    for next_node in temp:
        if next_node not in visited and next_node in graph :
            visited.append(next_node)
            return dfs(graph,next_node,visited)
        elif next_node in visited and next_node in graph :
            return "YES"
    return "NO"

inpt=open("input4.txt","r")
outpt=open("output4.txt","w")
temp=[int(i) for i in inpt.readline().split(" ")]
n,m=temp[0],temp[1]
graph = {}

for i in range(m):
    temp=[int(i) for i in inpt.readline().split(" ")]
    if  temp[0] not in graph:
        graph[temp[0]]=[temp[1]]
    else:
        graph[temp[0]].append(temp[1])


start=list(graph.keys())[0]
visited=[start]
result=dfs(graph, start, visited)
outpt.write(result)
outpt.close()
inpt.close()