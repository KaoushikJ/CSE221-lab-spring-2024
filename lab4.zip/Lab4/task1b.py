#Task 1b
inpt=open("input1b.txt","r")
outpt=open("output1b.txt","w")
temp=inpt.readline().split(" ")
vert=int(temp[0])
edge=int(temp[1])
arr=[""]*(vert+1)
for i in range(edge):
    temp=[int(j) for j in inpt.readline().split(" ")]
    arr[temp[0]]+=f"{temp[1] , temp[2]} "
for i in range(vert+1):
    outpt.write(f"{i}: {arr[i]}")
    if i!=vert:
        outpt.write("\n")
inpt.close()
outpt.close()