#Task 5
def quicksort(array):
    if len(array) < 2:
        return array
    else:
        return partition(array)

def partition(array):
    if True:
        pivot = array[0]
        less = []
        for i in range(1,len(array)):
            if array[i]<=pivot:
                less.append(array[i])
        greater = [] 
        for i in range(1,len(array)):
            if array[i]>pivot:
                greater.append(array[i])
        return quicksort(less) + [pivot] + quicksort(greater)

inpt=open("input5.txt","r")
outpt=open("output5.txt","w")
l=int(inpt.readline()) 
arr=[int(i) for i in inpt.readline().split(" ")]
new_arr=quicksort(arr)
for i in range(l):
    outpt.write(f"{new_arr[i]} ")
inpt.close()
outpt.close()