#task 3
def merge_and_count(arr, left, mid, right):
    temp = [0] * (right - left + 1)
    i, j, k, count = left, mid + 1, 0, 0

    while i <= mid and j <= right:
        if arr[i] <= arr[j]:
            temp[k] = arr[i]
            k += 1
            i += 1
        else:
            temp[k] = arr[j]
            count += (mid - i + 1)
            k += 1
            j += 1

    while i <= mid:
        temp[k] = arr[i]
        k += 1
        i += 1

    while j <= right:
        temp[k] = arr[j]
        k += 1
        j += 1

    for i in range(left, right + 1):
        arr[i] = temp[i - left]

    return count

def small_count(arr, left, right):
    count = 0
    if left < right:
        mid = (left + right) // 2
        count += small_count(arr, left, mid)
        count += small_count(arr, mid + 1, right)
        count += merge_and_count(arr, left, mid, right)
    return count

inpt=open('Input3.txt','r')
outpt=open('Output3.txt','w')

n = int(inpt.readline())
arr= [int(i) for i in inpt.readline().split(" ")]
count = small_count(arr, 0, n - 1)
outpt.write(str(count))
inpt.close()
outpt.close()