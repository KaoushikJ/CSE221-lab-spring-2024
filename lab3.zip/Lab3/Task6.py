#task 6
def partition(arr, p, r):
    pivot = arr[r]
    i = p - 1
    for j in range(p, r):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    arr[i+1], arr[r] = arr[r], arr[i+1]
    return i + 1

def kth_smallest(arr, p, r, k):
    if p == r:
        return arr[p]
    pivot_i = partition(arr, p, r)
    if k == pivot_i:
        return arr[k]
    elif k < pivot_i:
        return kth_smallest(arr, p, pivot_i - 1, k)
    else:
        return kth_smallest(arr, pivot_i + 1, r, k)

inpt=open("input6.txt","r")
outpt=open("output6.txt","w")

N = int(inpt.readline())
arr = [int(i) for i in inpt.readline().split(" ")]
Q = int(inpt.readline())
for i in range(Q):
    k = int(inpt.readline())
    outpt.write(f"{kth_smallest(arr, 0, N - 1, k - 1)}")
    if i<Q-1:
        outpt.write("\n")

inpt.close()
outpt.close()