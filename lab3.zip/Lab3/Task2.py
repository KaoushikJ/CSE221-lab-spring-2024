#task 2
def maxx(ar,sta,end):
    mid=(sta+end)//2
    if end-sta<=1:
        if ar[end]>ar[end-1]:
            return ar[end]
        else:
            return ar[end-1]

    l_max=maxx(ar,sta,mid)
    r_max=maxx(ar,mid+1,end)
    if l_max>r_max:
        return l_max
    else:
        return r_max
inp=open('input2.txt','r')
opt=open('output2.txt','w')
end=int(inp.readline())
ar=[int(i) for i in inp.readline().split(" ")]
opt.write(str(maxx(ar,0,end-1)))
inp.close()
opt.close()