#Task 4
def max_value(A):
    max_sum = -10**9 #as An is (-10^8 ≤ Ai ≤ 10^8)
    max_val = -10**9 #as An is (-10^8 ≤ Ai ≤ 10^8)
    for i in range(len(A)-1, -1, -1):
        max_sum = max(max_sum, A[i] + max_val)
        max_val = max(max_val, A[i]**2)
    return max_sum

inpt=open("input4.txt","r")
outpt=open("output4.txt","w")
l=int(inpt.readline())
arr=[int(i) for i in inpt.readline().split(" ")]
outpt.write(f"{max_value(arr)}")

inpt.close()
outpt.close()
