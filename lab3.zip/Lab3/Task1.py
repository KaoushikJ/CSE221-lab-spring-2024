#task 1
def merge(a,b):
    result = []
    i, j = 0, 0

    while i < len(a) and j < len(b):
        if a[i] < b[j]:
            result.append(a[i])
            i += 1
        else:
            result.append(b[j])
            j += 1

    result.extend(a[i:])
    result.extend(b[j:])
    return result

def mergeSort(arr):
    if len(arr) <= 1:
        return arr

    mid = len(arr) // 2
    left_half = arr[:mid]
    right_half = arr[mid:]
    a1 = mergeSort(left_half)
    a2 = mergeSort(right_half)
    return merge(a1, a2)

inpt=open("input1.txt","r")
outpt=open("output1.txt","w")
length=int(inpt.readline())

arr=[int(i) for i in inpt.readline().split(" ")]

new_arr=mergeSort(arr)

for i in range(length):
    outpt.write(f"{new_arr[i]} ")
inpt.close()
outpt.close()