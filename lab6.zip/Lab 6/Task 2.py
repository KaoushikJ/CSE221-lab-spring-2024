#Task 2
inpt=open("Input2.txt","r")
outpt=open("Output2.txt","w")
v,e=inpt.readline().split(" ")
v=int(v) #vertics
e=int(e) #edges

graph_map={}

for i in range(1,v+1):
    graph_map[i]=[]

for edge in range(e):
    temp=[int(i) for i in inpt.readline().split(" ")]
    graph_map[temp[0]].append((temp[1],temp[2]))

S,T=inpt.readline().strip().split(" ")
S=int(S)
T=int(T)


def dijkstra(graph,dis,s):
    V=list(graph_map.keys())
    for i in range(s-1):
        V.append(V.pop(0))
    for v in V:
        for current in graph_map[v]:
            if dis[current[0]]>current[1]+dis[v]:
                dis[current[0]]=current[1]+dis[v]
    for k in range(len(dis)):
        if dis[k]==float("inf"):
            dis[k]=-1
    return dis

dis=[float("inf")]*(v+1)
dis[S]=0
Dis_S=dijkstra(graph_map,dis,S)

dis=[float("inf")]*(v+1)
dis[T]=0

Dis_T=dijkstra(graph_map,dis,T)
x=True
for i in range(1,v+1):
    if Dis_S[i]!=-1 and Dis_T[i]!=-1:
        Time=max(Dis_S[i],Dis_T[i])
        outpt.write(f"Time: {Time}\nNode: {i}")
        x=False
        break
if x:
     outpt.write("Impossible")
outpt.close()
inpt.close()