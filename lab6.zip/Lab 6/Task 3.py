#Task 3
inpt=open("Input3.txt","r")
outpt=open("Output3.txt","w")
v,e=inpt.readline().split(" ")
v=int(v) #vertics
e=int(e) #edges

graph_map={}
denger_level=[float("inf")]*(v+1)

for i in range(1,v+1):
    graph_map[i]=[]

for edge in range(e):
    temp=[int(i) for i in inpt.readline().split(" ")]
    graph_map[temp[0]].append((temp[1],temp[2]))

denger_level[1]=0
par=[0]*(v+1)
par[1]=1


def dijkstra(graph,denger_level,par,s):
    V=list(graph_map.keys())
    for i in range(s-1):
        V.append(V.pop(0))
    for v in V:
        for current in graph_map[v]:
            if denger_level[current[0]]>current[1]:
                denger_level[current[0]]=current[1]
                par[current[0]]=v
    for k in range(len(denger_level)):
        if denger_level[k]==float("inf"):
            denger_level[k]=-1
    return denger_level

dijkstra(graph_map,denger_level,par,1)

levels=[]

def check_deng(parent,denger_level,levels,node):
    if parent[node]==node:
        return
    levels.append(denger_level[node])
    check_deng(parent,denger_level,levels,node-1)
check_deng(par,denger_level,levels,v)
outpt.write(f"{max(levels)}")
outpt.close()
inpt.close()