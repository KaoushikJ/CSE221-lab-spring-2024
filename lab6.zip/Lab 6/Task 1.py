#task 1
inpt=open("Input1.txt","r")
outpt=open("Output1.txt","w")
v,e=inpt.readline().split(" ")
v=int(v) #vertics
e=int(e) #edges

graph_map={}
dis=[float("inf")]*(v+1)

for i in range(1,v+1):
    graph_map[i]=[]

for edge in range(e):
    temp=[int(i) for i in inpt.readline().split(" ")]
    graph_map[temp[0]].append((temp[1],temp[2]))

source=int(inpt.readline().strip())
dis[source]=0

def dijkstra(graph,dis,s):
    V=list(graph_map.keys())
    for i in range(s-1):
        V.append(V.pop(0))
    for v in V:
        for dist in graph_map[v]:
            if dis[dist[0]]>dist[1]+dis[v]:
                dis[dist[0]]=dist[1]+dis[v]
    for k in range(len(dis)):
        if dis[k]==float("inf"):
            dis[k]=-1
dijkstra(graph_map,dis,source)

for i in range(1,len(dis)):
    outpt.write(f"{dis[i]} ")
inpt.close()
outpt.close()