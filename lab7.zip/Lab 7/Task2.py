#task 2
class DisjointSet:
    def __init__(self, n):
        self.parent = [i for i in range(n)]
        self.rank = [0] * n
    
    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]
    
    def union(self, x, y):
        x_root = self.find(x)
        y_root = self.find(y)
        
        if x_root == y_root:
            return False
        
        if self.rank[x_root] < self.rank[y_root]:
            self.parent[x_root] = y_root
        elif self.rank[x_root] > self.rank[y_root]:
            self.parent[y_root] = x_root
        else:
            self.parent[y_root] = x_root
            self.rank[x_root] += 1
        
        return True

def min_total_cost(edges, n):
    edges.sort(key=lambda x: x[2])
    total_cost = 0
    ds = DisjointSet(n)
    for edge in edges:
        u, v, w = edge
        if ds.union(u, v):
            total_cost += w
    return total_cost


# Input
inpt=open("Input2.txt","r")
N, M = inpt.readline().split()
N=int(N)
M=int(M)
roads = []
for _ in range(M):
    temp=[int(i) for i in inpt.readline().split()]
    u, v, w =temp[0],temp[1],temp[2]
    roads.append((u-1, v-1, w))  # Adjusting indices to start from 0

# Output
outpt=open("Output2.txt","w")
cost=min_total_cost(roads,N)
outpt.write(f"{cost}")
inpt.close()
outpt.close()
