#task 3
def up_stairs (n, memo):
    if memo[n]:
        return memo[n]
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        result = up_stairs (n - 1, memo) + up_stairs (n - 2, memo)
        memo[n] = result
        return result

input_file = open("Input3.txt", "r")
output_file =open("Output3.txt", "w")
input_number = int(input_file.read())


mamo_tab = {i: [] for i in range(input_number + 2)}
print(mamo_tab)

output_file.write(str(up_stairs (input_number + 1, mamo_tab)))
input_file.close()
output_file.close()
