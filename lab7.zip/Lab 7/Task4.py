#task 4
def min_coins(coins, amount):
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0

    for coin in coins:
        for i in range(coin, amount + 1):
            dp[i] = min(dp[i], dp[i - coin] + 1)

    return dp[amount] if dp[amount] != float('inf') else -1
inpt = open("/content/drive/MyDrive/Colab Notebooks/Lab7/Input4.txt", "r")
outpt = open("/content/drive/MyDrive/Colab Notebooks/Lab7/Output4.txt", "w")
# Input
temp= inpt.readline().split()
N, X =int(temp[0]),int(temp[1])
coins = [int(i) for i in inpt.readline().split()]
# Output
outpt.write(f"{min_coins(coins, X)}")

inpt.close()
outpt.close()