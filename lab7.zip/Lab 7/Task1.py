#task 1
inpt=open("Input1.txt","r")
outpt=open("Output1.txt","w")
t=inpt.readline().split(" ")
v=int(t[0])
iter=int(t[1])

parent=[0]*(v+1)
child_c=[1]*(v+1)

for i in range(1,v+1):
    parent[i]=i


for i in range(iter):
    v,u=inpt.readline().split(" ")
    v=int(v)
    u=int(u)
    if parent[u] != parent[v]:
        a = parent[u]
        b = parent[v]
        parent[a] = b
        child_c[b] = child_c[a] + child_c[b]
        outpt.write(f"{child_c[b]}\n")
    
    else:
        outpt.write(f"{child_c[parent[v]]}\n")
        
inpt.close()
outpt.close()
